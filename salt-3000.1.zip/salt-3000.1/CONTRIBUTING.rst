Developing Salt
===============

The Salt development team is welcoming, positive, and dedicated to
helping people get new code and fixes into SaltStack projects. Log into
GitHub and get started with one of the largest developer communities in
the world. The following links should get you started:

`<https://github.com/saltstack>`_

`<https://docs.saltstack.com/en/latest/topics/development/index.html>`_

`<https://docs.saltstack.com/en/develop/topics/development/pull_requests.html>`_
