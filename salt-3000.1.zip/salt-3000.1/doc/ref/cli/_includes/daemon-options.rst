.. option:: -u USER, --user=USER

    Specify user to run |salt-daemon|

.. option:: -d, --daemon

    Run |salt-daemon| as a daemon

.. option:: --pid-file PIDFILE

    Specify the location of the pidfile. Default: /var/run/|salt-daemon|.pid