=======================
salt.fileserver.azurefs
=======================

.. automodule:: salt.fileserver.azurefs
