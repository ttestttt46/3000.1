=============================
salt.beacons.network_settings
=============================

.. automodule:: salt.beacons.network_settings
    :members:
