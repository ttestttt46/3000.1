====================
salt.beacons.service
====================

.. automodule:: salt.beacons.service
    :members: