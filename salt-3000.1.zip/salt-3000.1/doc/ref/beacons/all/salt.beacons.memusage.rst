salt.beacons.memusage module
============================

.. automodule:: salt.beacons.memusage
    :members:
