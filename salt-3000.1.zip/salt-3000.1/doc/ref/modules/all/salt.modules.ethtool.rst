salt.modules.ethtool module
===========================

.. automodule:: salt.modules.ethtool
    :members:
