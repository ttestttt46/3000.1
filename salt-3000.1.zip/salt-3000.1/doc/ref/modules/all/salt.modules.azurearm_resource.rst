==============================
salt.modules.azurearm_resource
==============================

.. automodule:: salt.modules.azurearm_resource
    :members: