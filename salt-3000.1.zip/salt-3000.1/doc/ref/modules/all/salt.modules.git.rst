================
salt.modules.git
================

.. automodule:: salt.modules.git
    :members:
    :exclude-members: config_get_regex
