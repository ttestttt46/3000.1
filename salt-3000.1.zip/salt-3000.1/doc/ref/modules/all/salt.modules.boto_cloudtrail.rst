salt.modules.boto_cloudtrail module
===================================

.. automodule:: salt.modules.boto_cloudtrail
    :members:
