salt.modules.icinga2 module
===========================

.. automodule:: salt.modules.icinga2
    :members:
    :undoc-members:
