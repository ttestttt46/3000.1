=====================
salt.modules.defaults
=====================

.. automodule:: salt.modules.defaults
    :members: