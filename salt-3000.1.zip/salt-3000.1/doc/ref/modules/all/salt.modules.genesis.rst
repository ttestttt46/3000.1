====================
salt.modules.genesis
====================

.. automodule:: salt.modules.genesis
    :members: