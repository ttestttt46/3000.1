=====================
salt.modules.makeconf
=====================

.. automodule:: salt.modules.makeconf
    :members: