======================
salt.modules.ebuildpkg
======================

.. automodule:: salt.modules.ebuildpkg
    :members:
    :exclude-members: available_version
