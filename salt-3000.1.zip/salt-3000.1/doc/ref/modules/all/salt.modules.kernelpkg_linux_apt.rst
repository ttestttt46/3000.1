================================
salt.modules.kernelpkg_linux_apt
================================

.. automodule:: salt.modules.kernelpkg_linux_apt
    :members: