========================
salt.modules.ansiblegate
========================

.. automodule:: salt.modules.ansiblegate
    :members:
