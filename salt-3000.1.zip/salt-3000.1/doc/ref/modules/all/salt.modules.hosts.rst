==================
salt.modules.hosts
==================

.. automodule:: salt.modules.hosts
    :members: