=====================
salt.modules.mandrill
=====================

.. automodule:: salt.modules.mandrill
    :members:
