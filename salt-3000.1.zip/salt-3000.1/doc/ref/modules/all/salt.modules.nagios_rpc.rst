=======================
salt.modules.nagios_rpc
=======================

.. automodule:: salt.modules.nagios_rpc
    :members: