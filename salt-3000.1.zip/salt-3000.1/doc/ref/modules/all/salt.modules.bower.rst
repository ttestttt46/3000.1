==================
salt.modules.bower
==================

.. automodule:: salt.modules.bower
    :members: