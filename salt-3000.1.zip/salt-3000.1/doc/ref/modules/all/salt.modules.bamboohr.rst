=====================
salt.modules.bamboohr
=====================

.. automodule:: salt.modules.bamboohr
    :members:
