=====================
salt.modules.groupadd
=====================

.. automodule:: salt.modules.groupadd
    :members: