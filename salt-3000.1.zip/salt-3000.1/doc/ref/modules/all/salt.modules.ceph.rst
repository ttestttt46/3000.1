salt.modules.ceph module
========================

.. automodule:: salt.modules.ceph
    :members:
    :undoc-members:
