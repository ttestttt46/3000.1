salt.engines.docker_events module
=================================

.. automodule:: salt.engines.docker_events
    :members:
