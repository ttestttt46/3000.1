============================
salt.engines.logstash_engine
============================

.. automodule:: salt.engines.logstash_engine
    :members:
